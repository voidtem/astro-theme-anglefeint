import { createDecryptorController } from './modal-decryptor.js';
import { mountHelpKeyboard } from './modal-keyboard.js';
import { renderProgressModal } from './modal-progress.js';

let cleanupAboutModals = null;

export function initAboutModals(runtimeConfig, prefersReducedMotion) {
  if (cleanupAboutModals) cleanupAboutModals();

  const modalOverlay = document.getElementById('hacker-modal');
  const modalBody = document.getElementById('hacker-modal-body');
  const modalTitle = document.querySelector('.hacker-modal-title');
  if (!modalOverlay || !modalBody || !modalTitle) return;

  const decryptorKeysLabel =
    typeof runtimeConfig.decryptorKeysLabel === 'string' ? runtimeConfig.decryptorKeysLabel : '';
  const decryptor = createDecryptorController(
    modalOverlay,
    prefersReducedMotion,
    decryptorKeysLabel
  );
  let cleanupKeyboard = null;

  const scriptsTpl = document.getElementById('hacker-scripts-folders-tpl');
  const modalContent = runtimeConfig.modalContent;
  if (!modalContent || typeof modalContent !== 'object') return;

  const closeModal = () => {
    decryptor.stop();
    if (cleanupKeyboard) {
      cleanupKeyboard();
      cleanupKeyboard = null;
    }

    const modalEl = modalOverlay.querySelector('.hacker-modal');
    if (modalEl) modalEl.classList.remove('hacker-modal-wide');
    modalOverlay.classList.remove('open');
    modalOverlay.setAttribute('aria-hidden', 'true');
  };

  const openModal = (data) => {
    if (!data) return;

    decryptor.stop();
    if (cleanupKeyboard) {
      cleanupKeyboard();
      cleanupKeyboard = null;
    }

    const modalEl = modalOverlay.querySelector('.hacker-modal');
    if (modalEl) modalEl.classList.remove('hacker-modal-wide');

    modalTitle.textContent = data.title;
    modalBody.innerHTML = data.body;
    modalBody.className =
      'hacker-modal-body' +
      (data.type === 'progress' ? ' hacker-modal-download' : '') +
      (data.type === 'keyboard' ? ' hacker-modal-keyboard' : '') +
      (data.type === 'scripts' ? ' hacker-modal-scripts-wrap' : '');

    if (data.type === 'progress') {
      renderProgressModal();
    } else if (data.type === 'decryptor') {
      decryptor.prime();
      decryptor.start();
    } else if (data.type === 'keyboard') {
      if (modalEl) modalEl.classList.add('hacker-modal-wide');
      cleanupKeyboard = mountHelpKeyboard(modalOverlay, modalBody, runtimeConfig);
    } else if (data.type === 'scripts' && scriptsTpl) {
      modalBody.innerHTML = '';
      if ('content' in scriptsTpl && scriptsTpl.content) {
        modalBody.appendChild(scriptsTpl.content.cloneNode(true));
      } else {
        modalBody.appendChild(scriptsTpl.cloneNode(true));
        const cloned = modalBody.querySelector('#hacker-scripts-folders-tpl');
        if (cloned) {
          cloned.removeAttribute('id');
          cloned.hidden = false;
          cloned.removeAttribute('aria-hidden');
        }
      }
      if (modalEl) modalEl.classList.add('hacker-modal-wide');
    }

    modalOverlay.classList.add('open');
    modalOverlay.setAttribute('aria-hidden', 'false');
  };

  const folderButtons = Array.from(document.querySelectorAll('.hacker-folder[data-modal]'));
  const buttonHandlers = folderButtons.map((button) => {
    const onClick = () => {
      const id = button.getAttribute('data-modal');
      if (!id) return;
      openModal(modalContent[id]);
    };
    button.addEventListener('click', onClick);
    return [button, onClick];
  });

  const closeButton = document.querySelector('.hacker-modal-close');
  if (closeButton) closeButton.addEventListener('click', closeModal);

  const onOverlayClick = (event) => {
    if (event.target === modalOverlay) closeModal();
  };
  modalOverlay.addEventListener('click', onOverlayClick);

  const onDocumentKeydown = (event) => {
    if (event.key === 'Escape' && modalOverlay.classList.contains('open')) closeModal();
  };
  document.addEventListener('keydown', onDocumentKeydown);

  cleanupAboutModals = () => {
    decryptor.stop();
    if (cleanupKeyboard) {
      cleanupKeyboard();
      cleanupKeyboard = null;
    }
    if (closeButton) closeButton.removeEventListener('click', closeModal);
    modalOverlay.removeEventListener('click', onOverlayClick);
    document.removeEventListener('keydown', onDocumentKeydown);
    buttonHandlers.forEach(([button, handler]) => {
      button.removeEventListener('click', handler);
    });
  };

  return cleanupAboutModals;
}
